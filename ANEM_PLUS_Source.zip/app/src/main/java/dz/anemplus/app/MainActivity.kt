package dz.anemplus.app

import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent

class MainActivity : AppCompatActivity() {
    private val officialLogin = "https://auth.anem.dz/Account/Login"
    private val prefs by lazy { getSharedPreferences("anem_plus_preferences", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(0xFFF5F8F5.toInt())
        }

        page.addView(TextView(this).apply {
            text = "🇩🇿 ANEM PLUS"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(0xFF087A45.toInt())
        })

        page.addView(TextView(this).apply {
            text = "رفيقك الذكي لمتابعة ملف طالب العمل"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(0xFF4B5B50.toInt())
            setPadding(0, 18, 0, 24)
        })

        val emailInput = EditText(this).apply {
            hint = "البريد الإلكتروني"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            setSingleLine(true)
            setText(prefs.getString("saved_email", ""))
        }
        page.addView(emailInput, matchWidth())

        page.addView(Button(this).apply {
            text = "حفظ البريد الإلكتروني"
            isAllCaps = false
            setOnClickListener {
                val email = emailInput.text.toString().trim()
                if (email.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    emailInput.error = "أدخل بريداً إلكترونياً صحيحاً"
                } else {
                    prefs.edit().putString("saved_email", email).apply()
                    Toast.makeText(this@MainActivity, "تم حفظ البريد على هذا الجهاز", Toast.LENGTH_SHORT).show()
                }
            }
        }, matchWidth())

        page.addView(Button(this).apply {
            text = "الدخول إلى منصة ANEM الرسمية"
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF087A45.toInt())
            setOnClickListener {
                val email = emailInput.text.toString().trim()
                if (email.isNotBlank() && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    prefs.edit().putString("saved_email", email).apply()
                }
                // Password entry remains on the genuine ANEM domain.
                // Android/browser password manager can offer to save and autofill it there.
                CustomTabsIntent.Builder().build()
                    .launchUrl(this@MainActivity, Uri.parse(officialLogin))
            }
        }, matchWidth())

        page.addView(Button(this).apply {
            text = "حذف البريد المحفوظ"
            isAllCaps = false
            setOnClickListener {
                prefs.edit().remove("saved_email").apply()
                emailInput.text.clear()
                Toast.makeText(this@MainActivity, "تم حذف البريد المحفوظ", Toast.LENGTH_SHORT).show()
            }
        }, matchWidth())

        page.addView(TextView(this).apply {
            text = "لحماية حسابك، لا يخزن ANEM PLUS كلمة المرور. أدخلها فقط على auth.anem.dz، ويمكنك استخدام مدير كلمات المرور في Android أو المتصفح لحفظها وتعبئتها تلقائياً."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF59665D.toInt())
            setPadding(0, 24, 0, 0)
        }, matchWidth())

        setContentView(page)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 12 }
}
